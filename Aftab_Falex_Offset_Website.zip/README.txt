AFTAB FALEX OFFSET WEBSITE
===========================

Files:
- index.html

This is a responsive, mobile-friendly one-page website.

HTTPS:
The HTML itself cannot create an HTTPS address. To get a live https:// link,
upload this folder to a web host that provides an SSL certificate (many hosts
provide HTTPS automatically). Then connect your domain, if you have one.

Business details included:
Aftab Falex Offset
Ward No. 1, Swamber Nagar, Nagar Panchayat Itwa, Itwa,
Siddharth Nagar, Uttar Pradesh - 272192
Phone: 05541297063
